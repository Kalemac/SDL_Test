#pragma once
#ifndef GAMELOGICENUMS_H
#define GAMELOGICENUMS_H



enum class Facing // What direction the ship is facing on the map. Top of the screen is North.
{
	North = 0, East, South, West
};



#endif // !GAMELOGICENUMS_H
