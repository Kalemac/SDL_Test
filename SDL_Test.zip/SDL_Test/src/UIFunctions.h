#pragma once
#include "Game.h"

class UIFunciton {
public:
	static void RenderHPBar(int x, int y, int w, int h, float Percent, SDL_Color FGColor, SDL_Color BGColor);
};