#pragma once
#ifndef SHIPSYSTEM_H
#define SHIPSYSTEM_H


#include <string>
#include <stdlib.h>

using namespace std;

class ShipSystem // Generic ship system, will be parent of any others, mainly just weapons for now.
{
	string name;
};

#endif // !SHIPSYSTEM_H
